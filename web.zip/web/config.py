WTF_CSRF_ENABLED = True
SECRET_KEY = 'komandro'
UPLOAD_FOLDER = 'tmp/'
ALLOWED_EXTENSIONS = (['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])
